
exports.handler = async function(event) {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }

  try {
    const secret = process.env.PAYSTACK_SECRET_KEY;

    if (!secret) {
      throw new Error("Paystack secret key is not configured.");
    }

    const body = JSON.parse(event.body || "{}");
    const reference = String(body.reference || "").trim();

    if (!reference || !/^[a-zA-Z0-9_-]{1,100}$/.test(reference)) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Invalid payment reference." })
      };
    }

    const response = await fetch(
      "https://api.paystack.co/transaction/verify/" +
      encodeURIComponent(reference),
      {
        headers: {
          Authorization: "Bearer " + secret
        }
      }
    );

    const result = await response.json();

    if (!response.ok || !result.status) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Could not verify payment." })
      };
    }

    const payment = result.data;

    if (payment.status !== "success" || payment.currency !== "GHS") {
      return {
        statusCode: 400,
        body: JSON.stringify({ paid: false, message: "Payment is not successful." })
      };
    }

    return {
      statusCode: 200,
      body: JSON.stringify({
        paid: true,
        reference: payment.reference,
        amount: payment.amount,
        currency: payment.currency,
        message: "Payment verified successfully."
      })
    };

  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Payment verification failed." })
    };
  }
};
